<template>
  <div class="p-8">
    <h1 class="text-2xl font-bold mb-4">Mise à jour automatisée des tarifs</h1>
    <p>Module de gestion des tarifs et automatisation.</p>
  </div>
</template> 