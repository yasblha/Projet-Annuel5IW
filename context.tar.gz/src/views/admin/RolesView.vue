<template>
  <div class="p-8">
    <h1 class="text-2xl font-bold mb-4">Gestion des rôles</h1>
    <p>Module de gestion des rôles et habilitations.</p>
  </div>
</template> 