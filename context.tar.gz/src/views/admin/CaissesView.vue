<template>
  <div class="p-8">
    <h1 class="text-2xl font-bold mb-4">Gestion des caisses</h1>
    <p>Module de gestion des caisses et moyens de paiement.</p>
  </div>
</template> 