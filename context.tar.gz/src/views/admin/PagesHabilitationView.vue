<template>
  <div class="p-8">
    <h1 class="text-2xl font-bold mb-4">Pages & Habilitations</h1>
    <p>Module de gestion des habilitations d'accès aux pages.</p>
  </div>
</template> 