<template>
  <div class="container mx-auto px-4 py-6">
    <h1 class="text-2xl font-bold text-gray-900 mb-6">Maintenance</h1>
    <div class="bg-white shadow overflow-hidden sm:rounded-md p-6">
      <p class="text-gray-500">Module de maintenance à implémenter</p>
      <!-- Contenu à implémenter -->
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue';

onMounted(() => {
  console.log('MaintenanceView component mounted');
});
</script>
