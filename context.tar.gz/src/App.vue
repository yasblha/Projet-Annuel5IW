<template>
  <router-view />
  <NotificationContainer />
</template>
 
<script setup lang="ts">
import NotificationContainer from '@/components/ui/NotificationContainer.vue'
</script> 